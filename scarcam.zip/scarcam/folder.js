(() => {
  const msg = document.getElementById('msg');
  document.getElementById('pick').addEventListener('click', async () => {
    try {
      const dir = await window.showDirectoryPicker({ id: 'vcam-folder', mode: 'readwrite' });
      await VStore.set('dir', dir);
      await chrome.storage.local.set({ folderRev: Date.now() });
      const files = await VStore.scan(dir);
      msg.textContent = `Syncing “${dir.name}” — ${files.length} supported file${files.length === 1 ? '' : 's'} found. You can close this tab and open the extension.`;
    } catch (err) {
      msg.textContent = err && err.name === 'AbortError' ? 'No folder chosen.' : 'Could not open that folder: ' + (err && err.message || err);
    }
  });
})();
