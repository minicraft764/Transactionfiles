// Isolated-world bridge: storage <-> page-level injected.js (via window.postMessage).
// The (potentially large) media payload is only sent once the page actually requests the camera.
(() => {
  'use strict';
  const CH = '__VCAM_BRIDGE__';
  const DEFAULTS = { enabled: false, loop: true, playing: true, mediaId: null, mime: '' };
  let settings = null;
  let wantsMedia = false;

  const toPage = (msg, transfer) => {
    try { window.postMessage({ channel: CH, from: 'content', ...msg }, '*', transfer || []); } catch (_) {}
  };

  const dataUrlToBuffer = (dataUrl) => {
    const bin = atob(dataUrl.slice(dataUrl.indexOf(',') + 1));
    const bytes = new Uint8Array(bin.length);
    for (let i = 0; i < bin.length; i++) bytes[i] = bin.charCodeAt(i);
    return bytes.buffer;
  };

  async function pushSettings() {
    try {
      const { settings: s } = await chrome.storage.local.get('settings');
      settings = { ...DEFAULTS, ...(s || {}) };
      toPage({ type: 'settings', settings });
    } catch (_) { /* extension context invalidated (extension reloaded) */ }
  }

  async function pushMedia() {
    try {
      if (!settings || !settings.mediaId) return toPage({ type: 'media-clear' });
      const { media } = await chrome.storage.local.get('media');
      if (!media || media.id !== settings.mediaId) return;
      const buffer = dataUrlToBuffer(media.data);
      toPage({ type: 'media', id: media.id, mime: media.mime, buffer }, [buffer]);
    } catch (_) {}
  }

  window.addEventListener('message', (e) => {
    const d = e.data;
    if (e.source !== window || !d || d.channel !== CH || d.from !== 'page') return;
    if (d.type === 'ready') pushSettings();
    if (d.type === 'need-media') { wantsMedia = true; pushMedia(); }
  });

  try {
    chrome.storage.onChanged.addListener((changes, area) => {
      if (area !== 'local' || !changes.settings) return;
      const prevId = settings && settings.mediaId;
      settings = { ...DEFAULTS, ...(changes.settings.newValue || {}) };
      toPage({ type: 'settings', settings });
      // Live update: if this page already uses the camera, push the new file immediately.
      if (wantsMedia && settings.mediaId !== prevId) pushMedia();
    });
  } catch (_) {}

  pushSettings();
})();
