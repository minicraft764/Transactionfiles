// ScarCam shared helpers: remembers the chosen folder (IndexedDB) and lists supported files in it.
const VStore = (() => {
  const EXT = { png: 'image/png', jpg: 'image/jpeg', jpeg: 'image/jpeg', webp: 'image/webp', gif: 'image/gif', mp4: 'video/mp4', webm: 'video/webm' };

  const open = () => new Promise((res, rej) => {
    const r = indexedDB.open('vcam', 1);
    r.onupgradeneeded = () => r.result.createObjectStore('kv');
    r.onsuccess = () => res(r.result);
    r.onerror = () => rej(r.error);
  });
  async function tx(mode, fn) {
    const db = await open();
    return new Promise((res, rej) => {
      const t = db.transaction('kv', mode);
      const rq = fn(t.objectStore('kv'));
      t.oncomplete = () => { db.close(); res(rq && rq.result); };
      t.onerror = () => rej(t.error);
    });
  }

  // Lists supported media (newest first), including up to 3 levels of subfolders.
  async function scan(dir, maxFiles = 300, maxDepth = 3) {
    const out = [];
    async function walk(h, prefix, depth) {
      for await (const [name, entry] of h.entries()) {
        if (out.length >= maxFiles) return;
        if (name.startsWith('.')) continue;
        if (entry.kind === 'directory') {
          if (depth < maxDepth) await walk(entry, prefix + name + '/', depth + 1);
          continue;
        }
        const mime = EXT[name.split('.').pop().toLowerCase()];
        if (!mime) continue;
        try {
          const f = await entry.getFile();
          out.push({ path: prefix + name, name, handle: entry, mime, size: f.size, mtime: f.lastModified });
        } catch (_) { /* file vanished mid-scan */ }
      }
    }
    await walk(dir, '', 0);
    return out.sort((a, b) => b.mtime - a.mtime);
  }

  async function hasPermission(handle, request, mode = 'read') {
    const opts = { mode };
    if ((await handle.queryPermission(opts)) === 'granted') return true;
    return request ? (await handle.requestPermission(opts)) === 'granted' : false;
  }

  return {
    get: (k) => tx('readonly', (s) => s.get(k)),
    set: (k, v) => tx('readwrite', (s) => s.put(v, k)),
    del: (k) => tx('readwrite', (s) => s.delete(k)),
    scan, hasPermission, EXT
  };
})();
