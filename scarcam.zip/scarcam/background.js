// ScarCam service worker: default state, badge, keyboard shortcut.
const DEFAULTS = {
  enabled: false,
  loop: true,
  playing: true,
  muted: true,
  volume: 1,
  mediaId: null,
  name: '',
  mime: '',
  size: 0,
  srcPath: '',
  view: { x: 0.5, y: 0.5, zoom: 1, flip: false }
};

async function getSettings() {
  const { settings } = await chrome.storage.local.get('settings');
  return { ...DEFAULTS, ...(settings || {}) };
}

async function updateBadge() {
  const s = await getSettings();
  const live = s.enabled && s.mediaId;
  await chrome.action.setBadgeText({ text: live ? 'ON' : '' });
  await chrome.action.setBadgeBackgroundColor({ color: '#ff5a4e' });
  if (chrome.action.setBadgeTextColor) await chrome.action.setBadgeTextColor({ color: '#ffffff' });
}

chrome.runtime.onInstalled.addListener(async () => {
  await chrome.storage.local.set({ settings: await getSettings() });
  updateBadge();
});

chrome.runtime.onStartup.addListener(updateBadge);

chrome.storage.onChanged.addListener((changes, area) => {
  if (area === 'local' && changes.settings) updateBadge();
});

chrome.commands.onCommand.addListener(async (command) => {
  if (command !== 'toggle-camera') return;
  const s = await getSettings();
  await chrome.storage.local.set({ settings: { ...s, enabled: !s.enabled } });
});

chrome.runtime.onMessage.addListener((msg, _sender, sendResponse) => {
  if (msg && msg.type === 'get-settings') {
    getSettings().then(sendResponse);
    return true;
  }
});
