// ScarCam: runs in the PAGE's JS context (world: MAIN) at document_start.
// Every camera request is answered with a canvas.captureStream() whose source switches live:
//   ON  -> your chosen media (the real camera is released/stopped)
//   OFF -> the real camera, passed through, so your face is back without a refresh.
(() => {
  'use strict';
  if (window.__vcamInstalled || typeof MediaDevices === 'undefined') return;
  window.__vcamInstalled = true;

  const CH = '__VCAM_BRIDGE__';
  const md = navigator.mediaDevices;
  const origGUM = MediaDevices.prototype.getUserMedia.bind(md);
  const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
  const clamp = (v, lo, hi) => Math.min(hi, Math.max(lo, v));
  const post = (msg) => window.postMessage({ channel: CH, from: 'page', ...msg }, '*');

  const state = { enabled: false, loop: true, playing: true, mediaId: null };
  const VIEW0 = { x: 0.5, y: 0.5, zoom: 1, flip: false };
  const target = { ...VIEW0 };   // framing requested by the popup
  const cur = { ...VIEW0 };      // smoothed framing actually drawn
  let source = null;
  let loadedId = null, loadingId = null, loadToken = 0;
  let loadPromise = Promise.resolve();
  let stopTicker = null;
  const entries = new Set();   // { canvas, ctx, track, w, h, constraints, real, pending }

  let readyResolve;
  const ready = new Promise((r) => (readyResolve = r));
  setTimeout(readyResolve, 1500);

  const isActive = () => !!(state.enabled && source);

  /* ---------------------------- messaging ---------------------------- */
  window.addEventListener('message', (e) => {
    const d = e.data;
    if (e.source !== window || !d || d.channel !== CH || d.from !== 'content') return;
    if (d.type === 'settings') { applySettings(d.settings); readyResolve(); }
    else if (d.type === 'media') loadPromise = loadMedia(d.id, d.mime, d.buffer);
    else if (d.type === 'media-clear') { disposeSource(); loadedId = null; }
  });

  function applySettings(s) {
    state.enabled = !!s.enabled;
    state.loop = s.loop !== false;
    state.playing = s.playing !== false;
    state.mediaId = s.mediaId || null;
    Object.assign(target, VIEW0, s.view || {});
    if (!entries.size) Object.assign(cur, target);
    if (!state.mediaId) { disposeSource(); loadedId = null; }
    applyPlayback();
    if (entries.size && state.enabled) ensureMedia();
  }

  function ensureMedia() {
    if (state.mediaId && loadedId !== state.mediaId && loadingId !== state.mediaId) post({ type: 'need-media' });
  }

  async function waitForMedia() {
    if (loadedId === state.mediaId) return true;
    ensureMedia();
    const t0 = performance.now();
    while (performance.now() - t0 < 8000) {
      await loadPromise;
      if (loadedId === state.mediaId) return true;
      await sleep(50);
    }
    return false;
  }

  /* ------------------------- media sources -------------------------- */
  async function loadMedia(id, mime, buffer) {
    const token = ++loadToken;
    loadingId = id;
    let next = null;
    try { next = await buildSource(mime, buffer); } catch (err) { console.warn('[ScarCam] could not load media:', err); }
    if (token !== loadToken) { if (next) next.dispose(); return; }
    disposeSource();
    source = next;
    loadedId = next ? id : null;
    loadingId = null;
    applyPlayback();
  }

  async function buildSource(mime, buffer) {
    const blob = new Blob([buffer], { type: mime });
    if (mime.startsWith('video/')) {
      const v = document.createElement('video');
      const url = URL.createObjectURL(blob);
      v.muted = v.defaultMuted = true;
      v.playsInline = true;
      v.loop = state.loop;
      v.preload = 'auto';
      v.src = url;
      await new Promise((res, rej) => { v.onloadeddata = res; v.onerror = () => rej(new Error('video decode failed (blocked by page CSP?)')); });
      return { kind: 'video', el: v, dispose() { v.pause(); v.removeAttribute('src'); v.load(); URL.revokeObjectURL(url); } };
    }
    if ('ImageDecoder' in window && (mime === 'image/gif' || mime === 'image/webp')) {
      try { return await buildAnimated(buffer, mime); } catch (_) { /* fall back to still image */ }
    }
    const bmp = await createImageBitmap(blob);
    return { kind: 'bitmap', bmp, dispose() { bmp.close(); } };
  }

  async function buildAnimated(buffer, mime) {
    const dec = new ImageDecoder({ data: buffer, type: mime });
    await dec.tracks.ready;
    const count = dec.tracks.selectedTrack.frameCount;
    const first = await dec.decode({ frameIndex: 0 });
    let dead = false, pending = false, index = 0;
    let nextAt = performance.now() + Math.max(20, (first.image.duration || 100000) / 1000);
    const src = {
      kind: 'frame',
      frame: first.image,
      update(now) {
        if (dead || pending || count < 2 || !state.playing || now < nextAt) return;
        let next = index + 1;
        if (next >= count) { if (!state.loop) return; next = 0; }
        pending = true;
        dec.decode({ frameIndex: next }).then((r) => {
          if (dead) return r.image.close();
          const old = src.frame;
          src.frame = r.image;
          old.close();
          index = next;
          nextAt = performance.now() + Math.max(20, (r.image.duration || 100000) / 1000);
        }).catch(() => {}).finally(() => { pending = false; });
      },
      dispose() { dead = true; try { src.frame.close(); dec.close(); } catch (_) {} }
    };
    return src;
  }

  function disposeSource() {
    if (source) { try { source.dispose(); } catch (_) {} source = null; }
  }

  function applyPlayback() {
    if (!source || source.kind !== 'video') return;
    source.el.loop = state.loop;
    if (state.playing && entries.size) source.el.play().catch(() => {});
    else source.el.pause();
  }

  function drawable() {
    if (!source) return null;
    if (source.kind === 'video') {
      const v = source.el;
      return v.readyState >= 2 && v.videoWidth ? { el: v, w: v.videoWidth, h: v.videoHeight } : null;
    }
    if (source.kind === 'bitmap') return { el: source.bmp, w: source.bmp.width, h: source.bmp.height };
    return { el: source.frame, w: source.frame.displayWidth, h: source.frame.displayHeight };
  }

  /* ------------------- real camera (per stream, on demand) ------------------- */
  async function makeReal(stream) {
    const video = document.createElement('video');
    video.muted = true; video.playsInline = true; video.srcObject = stream;
    await video.play();
    return { video, stream };
  }

  function stopReal(info) {
    if (info) info.stream.getTracks().forEach((t) => t.stop());
  }

  // Turn the real camera OFF (light goes out) while the fake media is showing.
  function releaseReal(e) {
    if (e.real) { stopReal(e.real); e.real = null; }
  }

  // Turn the real camera back ON when the extension is switched off.
  async function acquireReal(e) {
    if (e.real || e.pending) return;
    e.pending = true;
    try {
      let s;
      try { s = await origGUM({ video: e.constraints || true, audio: false }); }
      catch (_) { s = await origGUM({ video: true, audio: false }); }
      const info = await makeReal(s);
      if (!entries.has(e) || isActive() || e.real) stopReal(info);
      else e.real = info;
    } catch (_) { /* camera unavailable or denied: black frame */ }
    e.pending = false;
  }

  /* ----------------------------- render loop ----------------------------- */
  function makeTicker(cb, ms) {
    let stop = () => {};
    let intervalId = null;
    const fallback = () => { if (!intervalId) { intervalId = setInterval(cb, ms); stop = () => clearInterval(intervalId); } };
    try {
      const url = URL.createObjectURL(new Blob([`setInterval(()=>postMessage(0),${ms})`], { type: 'text/javascript' }));
      const w = new Worker(url);
      setTimeout(() => URL.revokeObjectURL(url), 5000);
      w.onmessage = cb;
      w.onerror = (ev) => { ev.preventDefault(); w.terminate(); fallback(); };
      stop = () => w.terminate();
    } catch (_) { fallback(); }
    return () => stop();
  }

  const FADE_MS = 550;
  const ease = (t) => (t < 0.5 ? 4 * t * t * t : 1 - Math.pow(-2 * t + 2, 3) / 2);

  // Eases the drawn framing toward the requested one, so Fit / Fill / Reset glide.
  function stepView() {
    for (const p of ['x', 'y', 'zoom']) {
      const diff = target[p] - cur[p];
      cur[p] = Math.abs(diff) < 0.0008 ? target[p] : cur[p] + diff * 0.26;
    }
    cur.flip = target.flip;
  }

  function tick() {
    const now = performance.now();
    if (source && source.update) source.update(now);
    stepView();
    const active = isActive();
    const key = active ? 'm' + loadedId : 'r';

    for (const e of [...entries]) {
      if (e.track.readyState === 'ended') { releaseReal(e); entries.delete(e); continue; }
      if (active) releaseReal(e); else acquireReal(e);

      // Source changed (on/off or new media): freeze the last frame, then cross-fade into the new one.
      if (e.key !== key) {
        if (e.key !== null && e.drawn) {
          if (!e.snap) { e.snap = document.createElement('canvas'); e.snap.width = e.w; e.snap.height = e.h; }
          e.snap.getContext('2d').drawImage(e.canvas, 0, 0);
          e.fade = 'wait';
          e.waitSince = now;
        }
        e.key = key;
      }

      let d = null;
      if (active) d = drawable();
      else if (e.real && e.real.video.readyState >= 2 && e.real.video.videoWidth) {
        d = { el: e.real.video, w: e.real.video.videoWidth, h: e.real.video.videoHeight };
      }

      const ctx = e.ctx;
      if (d) {
        if (e.fade === 'wait') { e.fade = 'run'; e.fadeAt = now; }
        ctx.fillStyle = '#000';
        ctx.fillRect(0, 0, e.w, e.h);
        const base = Math.max(e.w / d.w, e.h / d.h);          // "cover" fit
        if (active) {
          const sc = base * cur.zoom, dw = d.w * sc, dh = d.h * sc;
          ctx.save();
          ctx.translate(cur.x * e.w, cur.y * e.h);
          if (cur.flip) ctx.scale(-1, 1);
          ctx.drawImage(d.el, -dw / 2, -dh / 2, dw, dh);
          ctx.restore();
        } else {
          ctx.drawImage(d.el, (e.w - d.w * base) / 2, (e.h - d.h * base) / 2, d.w * base, d.h * base);
        }
        if (e.fade === 'run') {
          const p = (now - e.fadeAt) / FADE_MS;
          if (p >= 1) e.fade = null;
          else { ctx.globalAlpha = 1 - ease(p); ctx.drawImage(e.snap, 0, 0); ctx.globalAlpha = 1; }
        }
        e.drawn = true;
      } else if (e.fade === 'wait' && now - e.waitSince < 3000) {
        ctx.drawImage(e.snap, 0, 0);                            // hold the old frame until the new source is ready
      } else {
        e.fade = null;
        ctx.fillStyle = '#000';
        ctx.fillRect(0, 0, e.w, e.h);
      }
    }
    if (!entries.size) idle();
  }

  function idle() {
    if (stopTicker) { stopTicker(); stopTicker = null; }
    if (source && source.kind === 'video') source.el.pause();
  }

  /* --------------------------- stream factory --------------------------- */
  function pick(x) {
    if (typeof x === 'number') return x;
    return x && typeof x === 'object' ? (x.exact ?? x.ideal ?? x.max ?? x.min ?? 0) : 0;
  }

  function createStream(vc, real) {
    let w = pick(vc.width), h = pick(vc.height), fps = pick(vc.frameRate) || 30;
    if (real) {   // match the real camera so quality is unchanged when passing through
      const s = real.stream.getVideoTracks()[0].getSettings();
      w = s.width || real.video.videoWidth || w; h = s.height || real.video.videoHeight || h; fps = s.frameRate || fps;
    }
    if (w && !h) h = Math.round((w * 9) / 16);
    else if (h && !w) w = Math.round((h * 16) / 9);
    else if (!w && !h) { w = 1280; h = 720; }
    w = clamp(Math.round(w), 160, 3840) & ~1;
    h = clamp(Math.round(h), 120, 2160) & ~1;
    fps = clamp(Math.round(fps), 1, 60);

    const canvas = document.createElement('canvas');
    canvas.width = w; canvas.height = h;
    const ctx = canvas.getContext('2d', { alpha: false });
    const stream = canvas.captureStream(fps);
    const track = stream.getVideoTracks()[0];
    const label = real ? real.stream.getVideoTracks()[0].label : 'ScarCam';
    try { Object.defineProperty(track, 'label', { value: label, configurable: true }); } catch (_) {}

    entries.add({ canvas, ctx, track, w, h, constraints: Object.keys(vc).length ? vc : true, real: real || null, pending: false, key: null, drawn: false, snap: null, fade: null });
    if (!stopTicker) stopTicker = makeTicker(tick, Math.round(1000 / 30));
    applyPlayback();
    tick();
    return stream;
  }

  /* ------------------------------ overrides ------------------------------ */
  async function patchedGUM(constraints) {
    if (!constraints || !constraints.video) return origGUM(constraints);
    await ready;
    const vc = typeof constraints.video === 'object' ? constraints.video : {};

    // ON: serve the chosen media; the real camera is never opened.
    if (state.enabled && state.mediaId && (await waitForMedia())) {
      const fake = createStream(vc, null);
      if (constraints.audio) {
        try {
          const a = await origGUM({ audio: constraints.audio });
          a.getAudioTracks().forEach((t) => fake.addTrack(t));
        } catch (err) {
          fake.getTracks().forEach((t) => t.stop());
          throw err;
        }
      }
      return fake;
    }

    // OFF: open the real camera but hand the page a proxy stream, so we can swap sources later.
    const real = await origGUM(constraints);          // permission errors reach the page unchanged
    const vt = real.getVideoTracks()[0];
    if (!vt) return real;
    let info;
    try { info = await makeReal(new MediaStream([vt])); } catch (_) { return real; }
    const out = createStream(vc, info);
    real.getAudioTracks().forEach((t) => out.addTrack(t));
    return out;
  }

  Object.defineProperty(MediaDevices.prototype, 'getUserMedia', { value: patchedGUM, writable: true, configurable: true });

  const legacy = function (constraints, ok, fail) {
    if (typeof ok !== 'function') throw new TypeError('successCallback is required');
    navigator.mediaDevices.getUserMedia(constraints).then(ok, fail || (() => {}));
  };
  ['getUserMedia', 'webkitGetUserMedia', 'mozGetUserMedia'].forEach((name) => {
    try { Object.defineProperty(navigator, name, { value: legacy, writable: true, configurable: true }); } catch (_) {}
  });

  post({ type: 'ready' });
})();
