(() => {
  'use strict';
  const $ = (id) => document.getElementById(id);
  const clamp = (v, a, b) => Math.min(b, Math.max(a, v));
  const MAX_BYTES = 40 * 1024 * 1024;
  const ALLOWED = ['image/png', 'image/jpeg', 'image/webp', 'image/gif', 'video/mp4', 'video/webm'];
  const VIEW0 = { x: 0.5, y: 0.5, zoom: 1, flip: false };
  const DEFAULTS = { enabled: false, loop: true, playing: true, muted: true, volume: 1, mediaId: null, name: '', mime: '', size: 0, srcPath: '', view: { ...VIEW0 } };

  const IDS = ['enabled', 'tally', 'status', 'stage', 'pv', 'pi', 'frame', 'empty', 'badge', 'remove', 'fname', 'zoomChip',
    'play', 'loop', 'flip', 'mute', 'volume', 'zoomRange', 'fit', 'fill', 'reset',
    'drop', 'file', 'libName', 'libMsg', 'libPick', 'libForget', 'libReconnect', 'grid',
    'panelLib', 'panelGif', 'q', 'keysBtn', 'chips', 'keys', 'keyKlipy', 'keyGiphy', 'gifMsg', 'gifGrid', 'more', 'credit'];
  const el = {};
  IDS.forEach((id) => { el[id] = $(id); });
  const tabsEl = document.querySelector('.tabs');

  let settings = { ...DEFAULTS, view: { ...VIEW0 } };
  let view = { ...VIEW0 };
  let previewUrl = null;
  let errored = false, flashing = false, flashTimer = null;

  const fmtSize = (b) => (b > 1048576 ? (b / 1048576).toFixed(1) + ' MB' : Math.max(1, Math.round(b / 1024)) + ' KB');
  const isVideo = () => settings.mime.startsWith('video/');
  const isAnimatable = () => isVideo() || settings.mime === 'image/gif' || settings.mime === 'image/webp';
  const safeName = (s) => (s || 'gif').toLowerCase().replace(/\s*gif$/i, '').replace(/[^a-z0-9]+/g, '-').replace(/^-+|-+$/g, '').slice(0, 40) || 'gif';

  /* ============================== status ============================== */
  function setStatus(text, error) {
    if (el.status.textContent !== text) {
      el.status.textContent = text;
      el.status.classList.remove('swap');
      void el.status.offsetWidth;
      el.status.classList.add('swap');
    }
    errored = !!error;
    el.status.classList.toggle('error', errored);
  }
  function flash(text) {
    flashing = true;
    setStatus(text);
    clearTimeout(flashTimer);
    flashTimer = setTimeout(() => { flashing = false; render(); }, 2600);
  }
  const fail = (text) => { flashing = false; setStatus(text, true); };

  /* ============================ persistence =========================== */
  async function save(patch) {
    settings = { ...settings, view: { ...view }, ...patch };
    if (patch.view) view = { ...patch.view };
    await chrome.storage.local.set({ settings });
    render();
  }

  let saveTimer = null, lastViewWrite = 0;
  function queueViewSave(final) {
    lastViewWrite = Date.now();
    if (final) { clearTimeout(saveTimer); saveTimer = null; writeView(); return; }
    if (!saveTimer) saveTimer = setTimeout(() => { saveTimer = null; writeView(); }, 70);
  }
  function writeView() {
    lastViewWrite = Date.now();
    settings = { ...settings, view: { ...view } };
    chrome.storage.local.set({ settings });
  }

  /* ============================== render ============================== */
  function render() {
    const has = !!settings.mediaId;
    const live = settings.enabled && has;
    el.enabled.checked = settings.enabled;
    el.tally.classList.toggle('live', live);
    el.stage.dataset.live = String(live);
    el.badge.textContent = live ? 'Live' : settings.enabled ? 'On · no media' : 'Off';
    el.badge.classList.toggle('on', live);
    if (!errored && !flashing) {
      setStatus(!has ? 'Choose a file to get started' : settings.enabled ? 'Live · sites see your media' : 'Off · sites see your real camera');
    }
    el.fname.textContent = has ? `${settings.name} · ${fmtSize(settings.size)}` : '';
    el.fname.hidden = !has;
    el.remove.hidden = !has;
    el.empty.hidden = has;

    el.play.disabled = el.loop.disabled = !isAnimatable();
    el.mute.disabled = el.volume.disabled = !isVideo();
    el.fit.disabled = el.fill.disabled = el.zoomRange.disabled = el.flip.disabled = !has;
    el.reset.disabled = !has;
    el.loop.setAttribute('aria-pressed', String(settings.loop));
    el.flip.setAttribute('aria-pressed', String(view.flip));
    $('ico-pause').hidden = !settings.playing;
    $('ico-play').hidden = settings.playing;
    $('ico-vol').hidden = settings.muted;
    $('ico-mute').hidden = !settings.muted;
    el.volume.value = settings.muted ? 0 : settings.volume;
    applyPreviewPlayback();
    markActive();
    layout();
  }

  /* ========================= preview + framing ======================== */
  let nat = { w: 0, h: 0 };
  let drag = null, animTimer = null, chipTimer = null;
  const mediaEl = () => (el.pv.hidden ? el.pi : el.pv);

  function layout() {
    if (!settings.mediaId || !nat.w) { el.frame.hidden = true; return; }
    const W = el.stage.clientWidth, H = el.stage.clientHeight;
    const sc = Math.max(W / nat.w, H / nat.h) * view.zoom;
    const dw = nat.w * sc, dh = nat.h * sc, cx = view.x * W, cy = view.y * H;
    const m = mediaEl().style;
    m.width = dw + 'px'; m.height = dh + 'px';
    m.left = cx - dw / 2 + 'px'; m.top = cy - dh / 2 + 'px';
    m.transform = view.flip ? 'scaleX(-1)' : '';
    const l = Math.max(0, cx - dw / 2), t = Math.max(0, cy - dh / 2), r = Math.min(W, cx + dw / 2), b = Math.min(H, cy + dh / 2);
    const f = el.frame.style;
    f.left = l + 'px'; f.top = t + 'px'; f.width = Math.max(0, r - l) + 'px'; f.height = Math.max(0, b - t) + 'px';
    el.frame.hidden = false;
    el.zoomRange.value = view.zoom;
    el.zoomChip.textContent = Math.round(view.zoom * 100) + '%';
  }

  function showChip() {
    el.zoomChip.classList.add('show');
    clearTimeout(chipTimer);
    chipTimer = setTimeout(() => el.zoomChip.classList.remove('show'), 900);
  }
  function glide() {
    el.stage.classList.add('anim');
    clearTimeout(animTimer);
    animTimer = setTimeout(() => el.stage.classList.remove('anim'), 450);
  }
  function setView(patch, { animate = false, final = false } = {}) {
    view = { ...view, ...patch };
    view.zoom = clamp(view.zoom, 0.1, 5);
    view.x = clamp(view.x, 0, 1);
    view.y = clamp(view.y, 0, 1);
    if (animate) glide();
    el.flip.setAttribute('aria-pressed', String(view.flip));
    layout();
    queueViewSave(final);
  }
  const containZoom = () => {
    const W = el.stage.clientWidth, H = el.stage.clientHeight;
    const a = W / nat.w, b = H / nat.h;
    return Math.min(a, b) / Math.max(a, b);
  };

  el.stage.addEventListener('pointerdown', (e) => {
    if (!settings.mediaId || e.button !== 0 || e.target.closest('button')) return;
    const r = el.stage.getBoundingClientRect();
    const handle = e.target.closest('.h');
    el.stage.setPointerCapture(e.pointerId);
    el.stage.classList.remove('anim');
    el.stage.classList.add('grab');
    const cx = r.left + view.x * r.width, cy = r.top + view.y * r.height;
    drag = { mode: handle ? 'scale' : 'move', sx: e.clientX, sy: e.clientY, v: { ...view }, r, cx, cy, d0: Math.hypot(e.clientX - cx, e.clientY - cy) || 1 };
    el.stage.focus({ preventScroll: true });
    e.preventDefault();
  });
  el.stage.addEventListener('pointermove', (e) => {
    if (!drag) return;
    if (drag.mode === 'move') {
      setView({ x: drag.v.x + (e.clientX - drag.sx) / drag.r.width, y: drag.v.y + (e.clientY - drag.sy) / drag.r.height });
    } else {
      setView({ zoom: drag.v.zoom * (Math.hypot(e.clientX - drag.cx, e.clientY - drag.cy) / drag.d0) });
      showChip();
    }
  });
  const endDrag = () => {
    if (!drag) return;
    drag = null;
    el.stage.classList.remove('grab');
    queueViewSave(true);
  };
  el.stage.addEventListener('pointerup', endDrag);
  el.stage.addEventListener('pointercancel', endDrag);
  el.stage.addEventListener('wheel', (e) => {
    if (!settings.mediaId) return;
    e.preventDefault();
    setView({ zoom: view.zoom * Math.exp(-e.deltaY * 0.0018) });
    showChip();
  }, { passive: false });
  el.stage.addEventListener('dblclick', (e) => {
    if (settings.mediaId && !e.target.closest('button')) { setView({ x: 0.5, y: 0.5, zoom: 1 }, { animate: true, final: true }); showChip(); }
  });
  el.stage.addEventListener('keydown', (e) => {
    if (!settings.mediaId) return;
    const step = e.shiftKey ? 0.05 : 0.01;
    const moves = { ArrowLeft: [-step, 0], ArrowRight: [step, 0], ArrowUp: [0, -step], ArrowDown: [0, step] };
    if (moves[e.key]) { setView({ x: view.x + moves[e.key][0], y: view.y + moves[e.key][1] }); e.preventDefault(); }
    else if (e.key === '+' || e.key === '=') { setView({ zoom: view.zoom * 1.06 }); showChip(); e.preventDefault(); }
    else if (e.key === '-') { setView({ zoom: view.zoom / 1.06 }); showChip(); e.preventDefault(); }
    else return;
    queueViewSave(false);
  });
  el.stage.addEventListener('keyup', () => queueViewSave(true));

  el.zoomRange.addEventListener('input', () => { setView({ zoom: Number(el.zoomRange.value) }); showChip(); });
  el.zoomRange.addEventListener('change', () => queueViewSave(true));
  el.fit.addEventListener('click', () => { if (nat.w) { setView({ x: 0.5, y: 0.5, zoom: containZoom() }, { animate: true, final: true }); showChip(); } });
  el.fill.addEventListener('click', () => { setView({ x: 0.5, y: 0.5, zoom: 1 }, { animate: true, final: true }); showChip(); });
  el.reset.addEventListener('click', () => { setView({ ...VIEW0 }, { animate: true, final: true }); showChip(); });
  el.flip.addEventListener('click', () => setView({ flip: !view.flip }, { animate: true, final: true }));
  new ResizeObserver(layout).observe(el.stage);

  function applyPreviewPlayback() {
    if (el.pv.hidden) return;
    el.pv.loop = settings.loop;
    el.pv.muted = settings.muted;
    el.pv.volume = settings.volume;
    if (settings.playing) el.pv.play().catch(() => {}); else el.pv.pause();
  }

  function showPreview(blob, mime) {
    if (previewUrl) URL.revokeObjectURL(previewUrl);
    previewUrl = blob ? URL.createObjectURL(blob) : null;
    nat = { w: 0, h: 0 };
    el.pv.hidden = el.pi.hidden = true;
    el.pv.removeAttribute('src'); el.pi.removeAttribute('src');
    if (!blob) return layout();
    if (mime.startsWith('video/')) { el.pv.src = previewUrl; el.pv.hidden = false; }
    else { el.pi.src = previewUrl; el.pi.hidden = false; }
    applyPreviewPlayback();
  }
  el.pv.addEventListener('loadedmetadata', () => { nat = { w: el.pv.videoWidth, h: el.pv.videoHeight }; layout(); });
  el.pi.addEventListener('load', () => { nat = { w: el.pi.naturalWidth, h: el.pi.naturalHeight }; layout(); });

  /* ============================ file handling ========================= */
  function resolveMime(file) {
    if (ALLOWED.includes(file.type)) return file.type;
    return VStore.EXT[(file.name.split('.').pop() || '').toLowerCase()] || '';
  }
  const readAsDataURL = (file) => new Promise((res, rej) => {
    const r = new FileReader();
    r.onload = () => res(r.result);
    r.onerror = () => rej(r.error);
    r.readAsDataURL(file);
  });

  async function handleFile(file, srcPath = '') {
    if (!file) return false;
    const mime = resolveMime(file);
    if (!mime) { fail('Unsupported file. Use PNG, JPG, WebP, GIF, MP4 or WebM.'); return false; }
    if (file.size > MAX_BYTES) { fail('File is over 40 MB. Choose a smaller one.'); return false; }
    try {
      flashing = false; errored = false;
      let data = await readAsDataURL(file);
      data = data.replace(/^data:[^;,]*/, 'data:' + mime);
      const id = Date.now().toString(36) + Math.random().toString(36).slice(2, 7);
      view = { ...VIEW0, flip: view.flip };        // new media starts filled; mirror preference is kept
      settings = { ...settings, mediaId: id, name: file.name, mime, size: file.size, playing: true, srcPath, view: { ...view } };
      await chrome.storage.local.set({ media: { id, mime, data }, settings });   // one atomic write → live update
      showPreview(file, mime);
      render();
      return true;
    } catch (err) {
      fail('Could not save this file: ' + (err && err.message ? err.message : err));
      return false;
    }
  }

  async function removeMedia() {
    await chrome.storage.local.remove('media');
    errored = false;
    showPreview(null);
    view = { ...VIEW0, flip: view.flip };
    await save({ mediaId: null, name: '', mime: '', size: 0, srcPath: '', view: { ...view } });
  }

  /* ============================= library ============================== */
  let dir = null, entries = [], sig = '';
  const thumbCache = new Map(), thumbJobs = [];
  let thumbRunning = 0;

  function markActive() {
    el.grid.querySelectorAll('.tile').forEach((t) => {
      const on = !!settings.srcPath && t.dataset.path === settings.srcPath && !!settings.mediaId;
      t.classList.toggle('active', on);
      t.setAttribute('aria-selected', String(on));
    });
  }

  function folderUi(state, message) {
    el.libName.textContent = dir ? dir.name : 'No folder synced';
    el.libForget.hidden = !dir;
    el.libPick.textContent = dir ? 'Change' : 'Choose folder';
    el.libReconnect.hidden = state !== 'permission';
    el.grid.hidden = state !== 'ok' || !entries.length;
    el.libMsg.hidden = state === 'ok' && entries.length > 0;
    if (state === 'none') el.libMsg.textContent = 'Pick a folder and every image, GIF and video in it appears here, ready to switch between.';
    else if (state === 'permission') el.libMsg.textContent = 'Allow access to this folder again to load your files.';
    else if (state === 'error') el.libMsg.textContent = message || 'This folder is no longer available. Choose it again.';
    else if (!entries.length) el.libMsg.textContent = 'No supported files here yet. New ones appear automatically.';
  }

  async function syncFolder(requestPermission) {
    if (!dir) return folderUi('none');
    let ok = false;
    try { ok = await VStore.hasPermission(dir, requestPermission); } catch (_) { return folderUi('error'); }
    if (!ok) return folderUi('permission');
    try {
      const list = await VStore.scan(dir);
      const next = list.map((e) => `${e.path}|${e.size}|${e.mtime}`).join('\n');
      if (next !== sig) { sig = next; entries = list; renderGrid(); }
      folderUi('ok');
    } catch (_) {
      entries = []; sig = ''; renderGrid();
      folderUi('error');
    }
  }

  function renderGrid() {
    el.grid.textContent = '';
    entries.forEach((e, i) => {
      const tooBig = e.size > MAX_BYTES;
      const b = document.createElement('button');
      b.type = 'button';
      b.className = 'tile' + (tooBig ? ' big' : '');
      b.style.animationDelay = Math.min(i, 12) * 18 + 'ms';
      b.dataset.path = e.path;
      b.dataset.kind = e.mime.startsWith('video/') ? 'video' : 'image';
      b.setAttribute('role', 'option');
      b.title = tooBig ? `${e.path} (over 40 MB)` : e.path;
      b.setAttribute('aria-label', b.title);
      const img = document.createElement('img');
      img.alt = '';
      img.addEventListener('load', () => img.classList.add('in'));
      const nm = document.createElement('span');
      nm.className = 'nm';
      nm.textContent = e.name;
      b.append(img, nm);
      if (!tooBig) {
        b.addEventListener('click', () => pickEntry(e));
        queueThumb(e, img);
      }
      el.grid.appendChild(b);
    });
    markActive();
  }

  async function pickEntry(e) {
    try { await handleFile(await e.handle.getFile(), e.path); }
    catch (_) { fail('Could not read that file. It may have been moved or deleted.'); syncFolder(false); }
  }

  function queueThumb(e, img) {
    const key = `${e.path}|${e.size}|${e.mtime}`;
    if (thumbCache.has(key)) { img.src = thumbCache.get(key); return; }
    thumbJobs.push({ e, img, key });
    pumpThumbs();
  }
  function pumpThumbs() {
    while (thumbRunning < 2 && thumbJobs.length) {
      const j = thumbJobs.shift();
      thumbRunning++;
      makeThumb(j.e)
        .then((url) => { if (url) { thumbCache.set(j.key, url); j.img.src = url; } })
        .catch(() => {})
        .finally(() => { thumbRunning--; pumpThumbs(); });
    }
  }
  async function makeThumb(e) {
    const f = await e.handle.getFile();
    const W = 128, H = 80;
    const c = document.createElement('canvas');
    c.width = W; c.height = H;
    let src, w, h, cleanup;
    if (e.mime.startsWith('video/')) {
      const v = document.createElement('video');
      const url = URL.createObjectURL(f);
      v.muted = true; v.preload = 'auto'; v.src = url;
      cleanup = () => { URL.revokeObjectURL(url); v.removeAttribute('src'); v.load(); };
      try {
        await new Promise((res, rej) => {
          const t = setTimeout(() => rej(new Error('timeout')), 5000);
          v.onloadeddata = () => { v.currentTime = Math.min(0.5, (v.duration || 1) / 2); };
          v.onseeked = () => { clearTimeout(t); res(); };
          v.onerror = () => { clearTimeout(t); rej(new Error('decode')); };
        });
      } catch (err) { cleanup(); throw err; }
      src = v; w = v.videoWidth; h = v.videoHeight;
    } else {
      const bmp = await createImageBitmap(f, { resizeWidth: 256 });
      src = bmp; w = bmp.width; h = bmp.height;
      cleanup = () => bmp.close();
    }
    const s = Math.max(W / w, H / h);
    c.getContext('2d').drawImage(src, (W - w * s) / 2, (H - h * s) / 2, w * s, h * s);
    cleanup();
    return c.toDataURL('image/jpeg', 0.72);
  }

  async function loadDir() {
    try { dir = (await VStore.get('dir')) || null; } catch (_) { dir = null; }
    sig = '';
    await syncFolder(false);
  }

  /* =============================== GIFs =============================== */
  let keys = { giphy: '', klipy: '', customerId: '' };
  const gs = { q: '', sel: '', page: {}, has: {}, loading: false, seq: 0, started: false };

  async function getJSON(url) {
    const r = await fetch(url);
    if (r.status === 401 || r.status === 403) throw new Error('API key rejected');
    if (r.status === 429) throw new Error('Rate limit reached, try again soon');
    if (!r.ok) throw new Error('HTTP ' + r.status);
    return r.json();
  }
  const firstUrl = (obj, names) => { for (const n of names) if (obj && obj[n] && obj[n].url) return obj[n].url; return ''; };

  const PROVIDERS = {
    klipy: {
      name: 'KLIPY',
      async search(key, q, page) {
        const u = new URL(`https://api.klipy.com/api/v1/${encodeURIComponent(key)}/gifs/${q ? 'search' : 'trending'}`);
        if (q) u.searchParams.set('q', q);
        u.searchParams.set('page', page + 1);
        u.searchParams.set('per_page', 24);
        if (keys.customerId) u.searchParams.set('customer_id', keys.customerId);
        const j = await getJSON(u);
        const arr = (j && j.data && j.data.data) || [];
        const items = [];
        for (const g of arr) {
          const f = g && (g.file || g.files);
          if (!f) continue;                                  // skip ad entries
          const g2 = (s) => (f[s] && f[s].gif && f[s].gif.url) || '';
          const preview = g2('sm') || g2('md') || g2('xs') || g2('hd') || (f.gif && f.gif.url) || '';
          const full = g2('hd') || g2('md') || g2('sm') || (f.gif && f.gif.url) || preview;
          if (preview) items.push({ id: String(g.slug || g.id), title: g.title || g.slug || 'gif', preview, full, provider: 'klipy' });
        }
        return { items, hasNext: !!(j && j.data && j.data.has_next) };
      }
    },
    giphy: {
      name: 'GIPHY',
      async search(key, q, page) {
        const per = 24;
        const u = new URL(`https://api.giphy.com/v1/gifs/${q ? 'search' : 'trending'}`);
        u.searchParams.set('api_key', key || GIPHY_DEMO);
        if (q) u.searchParams.set('q', q);
        u.searchParams.set('limit', per);
        u.searchParams.set('offset', page * per);
        u.searchParams.set('rating', 'pg-13');
        const j = await getJSON(u);
        const items = (j.data || []).map((g) => ({
          id: g.id, title: g.title || 'gif', provider: 'giphy',
          preview: firstUrl(g.images, ['fixed_width', 'fixed_width_small', 'downsized']),
          full: firstUrl(g.images, ['original', 'downsized_large', 'fixed_height'])
        })).filter((x) => x.preview && x.full);
        const p = j.pagination;
        return { items, hasNext: p ? p.offset + p.count < p.total_count : items.length === per };
      }
    }
  };
  /* ---- sources that need no account ---- */
  const GIPHY_DEMO = 'dc6zaTOxFJmzC';   // Giphy's public beta key; used until you add your own
  PROVIDERS.giphy.keyless = true;

  PROVIDERS.commons = {
    name: 'Wikimedia', keyless: true,
    async search(_key, q, page) {
      const per = 24;
      const u = new URL('https://commons.wikimedia.org/w/api.php');
      const p = u.searchParams;
      p.set('action', 'query'); p.set('format', 'json'); p.set('origin', '*');
      p.set('generator', 'search'); p.set('gsrnamespace', '6');
      p.set('gsrsearch', `${q || 'animation'} intitle:gif`);
      p.set('gsrlimit', per); p.set('gsroffset', page * per);
      p.set('prop', 'imageinfo'); p.set('iiprop', 'url|mime|size'); p.set('iiurlwidth', '240');
      const j = await getJSON(u);
      const pages = Object.values((j.query && j.query.pages) || {}).sort((a, b) => (a.index || 0) - (b.index || 0));
      const items = [];
      for (const pg of pages) {
        const ii = pg.imageinfo && pg.imageinfo[0];
        if (!ii || ii.mime !== 'image/gif' || ii.size > MAX_BYTES) continue;
        items.push({ id: String(pg.pageid), title: pg.title.replace(/^File:/, '').replace(/\.gif$/i, '').replace(/_/g, ' '), preview: ii.thumburl || ii.url, full: ii.url, provider: 'commons' });
      }
      return { items, hasNext: !!j.continue };
    }
  };

  PROVIDERS.openverse = {
    name: 'Openverse', keyless: true,
    async search(_key, q, page) {
      const u = new URL('https://api.openverse.org/v1/images/');
      u.searchParams.set('q', q || 'animated');
      u.searchParams.set('extension', 'gif');
      u.searchParams.set('page_size', 20);          // anonymous requests are capped at 20 per page
      u.searchParams.set('page', page + 1);
      const j = await getJSON(u);
      const items = (j.results || []).filter((r) => r.url && (r.filetype || 'gif') === 'gif').map((r) => ({
        id: String(r.id), title: r.title || 'gif', provider: 'openverse', preview: r.thumbnail || r.url, full: r.url
      }));
      return { items, hasNext: !!j.page_count && (j.page || page + 1) < j.page_count };
    }
  };

  const CREDITS = {
    giphy: 'Powered by GIPHY',
    klipy: 'Powered by KLIPY',
    commons: 'Wikimedia Commons · free-licensed files, check each license before reuse',
    openverse: 'Openverse · free-licensed files, check licenses · limited requests per hour'
  };
  const configured = () => ['giphy', 'commons', 'klipy', 'openverse'].filter((p) => PROVIDERS[p].keyless || keys[p]);

  async function fetchBlob(url) {
    try { return await (await fetchOk(url)).blob(); }
    catch (err) {
      // CDN without CORS: ask for access to just that host, then retry.
      const origin = new URL(url).origin + '/*';
      let granted = false;
      try { granted = await chrome.permissions.request({ origins: [origin] }); } catch (_) {}
      if (!granted) throw err;
      return (await fetchOk(url)).blob();
    }
  }
  async function fetchOk(url) {
    const r = await fetch(url);
    if (!r.ok) throw new Error('HTTP ' + r.status);
    return r;
  }

  function renderChips() {
    const cfg = configured();
    const opts = cfg.length > 1 ? ['all', ...cfg] : cfg;
    if (!opts.includes(gs.sel)) gs.sel = opts[0] || '';
    el.chips.textContent = '';
    el.chips.hidden = opts.length < 2;
    opts.forEach((o) => {
      const b = document.createElement('button');
      b.type = 'button';
      b.className = 'chipbtn';
      b.textContent = o === 'all' ? 'All' : PROVIDERS[o].name;
      b.setAttribute('aria-pressed', String(o === gs.sel));
      b.addEventListener('click', () => { gs.sel = o; renderChips(); runSearch(true); });
      el.chips.appendChild(b);
    });
    el.q.placeholder = gs.sel === 'klipy' ? 'Search KLIPY' : gs.sel === 'giphy' ? 'Search GIPHY' : 'Search GIFs';
    el.credit.textContent = gs.sel === 'all' ? 'Mixed sources (Openverse has its own chip). Wikimedia files are free-licensed, check each license.' : CREDITS[gs.sel] || '';
  }

  function setKeysOpen(open) {
    el.keys.hidden = !open;
    el.keysBtn.setAttribute('aria-expanded', String(open));
  }

  async function startGifs() {
    gs.started = true;
    try {
      const { keys: k } = await chrome.storage.local.get('keys');
      keys = { ...keys, ...(k || {}) };
      if (!keys.customerId) { keys.customerId = crypto.randomUUID(); await chrome.storage.local.set({ keys }); }
    } catch (_) {}
    el.keyKlipy.value = keys.klipy; el.keyGiphy.value = keys.giphy;
    renderChips();
    if (!configured().length) { setKeysOpen(true); el.gifMsg.textContent = 'Add a free API key to search GIFs.'; return; }
    setKeysOpen(false);
    runSearch(true);
  }

  function gifTile(item, i) {
    const w = document.createElement('div');
    w.className = 'gtile';
    w.style.animationDelay = Math.min(i, 9) * 22 + 'ms';
    const pick = document.createElement('button');
    pick.type = 'button'; pick.className = 'pick';
    pick.title = 'Use ' + item.title; pick.setAttribute('aria-label', 'Use ' + item.title);
    const img = document.createElement('img');
    img.alt = ''; img.loading = 'lazy'; img.src = item.preview;
    img.addEventListener('load', () => img.classList.add('in'));
    pick.appendChild(img);
    const dl = document.createElement('button');
    dl.type = 'button'; dl.className = 'dl';
    dl.title = 'Download to your synced folder'; dl.setAttribute('aria-label', 'Download ' + item.title);
    dl.innerHTML = '<svg class="dlico" viewBox="0 0 24 24" width="14" height="14" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><path d="M12 4v11m0 0-4-4m4 4 4-4M5 20h14"/></svg>';
    pick.addEventListener('click', () => useGif(item, w));
    dl.addEventListener('click', (ev) => { ev.stopPropagation(); downloadGif(item, dl); });
    w.append(pick, dl);
    return w;
  }

  async function runSearch(reset) {
    const cfg = configured();
    if (!cfg.length) return;
    if (reset) {
      gs.seq++; gs.page = {}; gs.has = {};
      el.gifGrid.textContent = '';
      el.gifGrid.scrollTop = 0;
      el.panelGif.scrollTop = 0;
    } else if (gs.loading) return;
    const seq = gs.seq;
    const provs = (gs.sel === 'all' ? cfg.filter((p) => p !== 'openverse') : [gs.sel]).filter((p) => reset || gs.has[p]);
    if (!provs.length) return;
    gs.loading = true;
    el.more.hidden = true;
    el.gifMsg.textContent = reset ? 'Searching…' : '';
    const results = await Promise.allSettled(provs.map((p) => PROVIDERS[p].search(keys[p], gs.q, gs.page[p] || 0).then((r) => ({ p, r }))));
    if (seq !== gs.seq) return;
    gs.loading = false;
    const lists = [], errs = [];
    results.forEach((res, i) => {
      if (res.status === 'fulfilled') {
        const { p, r } = res.value;
        gs.page[p] = (gs.page[p] || 0) + 1; gs.has[p] = r.hasNext; lists.push(r.items);
      } else { gs.has[provs[i]] = false; errs.push(`${PROVIDERS[provs[i]].name}: ${res.reason && res.reason.message || 'failed'}`); }
    });
    const merged = [];                                    // round-robin so "All" mixes sources
    for (let i = 0; lists.some((l) => i < l.length); i++) lists.forEach((l) => { if (i < l.length) merged.push(l[i]); });
    const base = el.gifGrid.children.length;
    merged.forEach((it, i) => el.gifGrid.appendChild(gifTile(it, i)));
    el.gifMsg.textContent = errs.length ? errs.join(' · ') : (!el.gifGrid.children.length ? `No GIFs found${gs.q ? ' for “' + gs.q + '”' : ''}.` : '');
    el.more.hidden = !Object.values(gs.has).some(Boolean);
    if (!base && errs.length && errs.some((e) => /key rejected/.test(e))) setKeysOpen(true);
  }

  async function useGif(item, tile) {
    if (tile.classList.contains('busy')) return;
    tile.classList.add('busy');
    try {
      const blob = await fetchBlob(item.full);
      const file = new File([blob], `${safeName(item.title)}-${item.id.slice(0, 8)}.gif`, { type: 'image/gif' });
      if (await handleFile(file, '')) {
        el.gifGrid.querySelectorAll('.gtile.live').forEach((t) => t.classList.remove('live'));
        tile.classList.add('live');
        flash('Now showing ' + (item.title || 'GIF'));
      }
    } catch (_) { fail('Could not load that GIF. Try another.'); }
    tile.classList.remove('busy');
  }

  async function downloadGif(item, btn) {
    if (btn.classList.contains('busy')) return;
    if (!dir) { fail('Choose a folder in Library first, then download.'); switchTab('lib'); return; }
    btn.classList.add('busy');
    try {
      if (!(await VStore.hasPermission(dir, true, 'readwrite'))) throw new Error('Folder access was not allowed.');
      const blob = await fetchBlob(item.full);
      const base = `${safeName(item.title)}-${item.id.slice(0, 8)}`;
      let name = base + '.gif', n = 2;
      for (;;) {                                           // never overwrite an existing file
        try { await dir.getFileHandle(name); name = `${base}-${n++}.gif`; } catch (_) { break; }
      }
      const fh = await dir.getFileHandle(name, { create: true });
      const w = await fh.createWritable();
      await w.write(blob);
      await w.close();
      btn.classList.remove('busy'); btn.classList.add('done');
      setTimeout(() => btn.classList.remove('done'), 1800);
      flash(`Saved ${name} to ${dir.name}`);
      syncFolder(false);
    } catch (err) {
      btn.classList.remove('busy');
      fail('Could not save: ' + (err && err.message ? err.message : err));
    }
  }

  /* =============================== tabs =============================== */
  function switchTab(name) {
    tabsEl.dataset.active = name;
    document.querySelectorAll('.tab').forEach((t) => t.setAttribute('aria-selected', String(t.dataset.tab === name)));
    el.panelLib.hidden = name !== 'lib';
    el.panelGif.hidden = name !== 'gif';
    if (name === 'gif' && !gs.started) startGifs();
  }
  document.querySelectorAll('.tab').forEach((t) => t.addEventListener('click', () => switchTab(t.dataset.tab)));

  /* ============================== events ============================== */
  el.enabled.addEventListener('change', () => save({ enabled: el.enabled.checked }));
  el.file.addEventListener('change', () => { handleFile(el.file.files[0]); el.file.value = ''; });
  el.drop.addEventListener('keydown', (e) => { if (e.key === 'Enter' || e.key === ' ') { e.preventDefault(); el.file.click(); } });
  ['dragenter', 'dragover'].forEach((t) => document.body.addEventListener(t, (e) => { e.preventDefault(); el.drop.classList.add('over'); }));
  ['dragleave', 'drop'].forEach((t) => document.body.addEventListener(t, (e) => { e.preventDefault(); el.drop.classList.remove('over'); }));
  document.body.addEventListener('drop', (e) => handleFile(e.dataTransfer.files[0]));
  el.remove.addEventListener('click', removeMedia);
  el.play.addEventListener('click', () => save({ playing: !settings.playing }));
  el.loop.addEventListener('click', () => save({ loop: !settings.loop }));
  el.mute.addEventListener('click', () => save({ muted: !settings.muted }));
  el.volume.addEventListener('input', () => { const v = Number(el.volume.value); el.pv.volume = v; el.pv.muted = v === 0; });
  el.volume.addEventListener('change', () => { const v = Number(el.volume.value); save({ volume: v || settings.volume, muted: v === 0 }); });

  el.libPick.addEventListener('click', () => chrome.tabs.create({ url: chrome.runtime.getURL('folder.html') }));
  el.libReconnect.addEventListener('click', () => syncFolder(true));
  el.libForget.addEventListener('click', async () => {
    await VStore.del('dir');
    dir = null; entries = []; sig = '';
    renderGrid();
    folderUi('none');
  });

  let searchTimer = null;
  el.q.addEventListener('input', () => {
    clearTimeout(searchTimer);
    searchTimer = setTimeout(() => { gs.q = el.q.value.trim(); runSearch(true); }, 400);
  });
  el.more.addEventListener('click', () => runSearch(false));
  el.panelGif.addEventListener('scroll', () => {
    const p = el.panelGif;
    if (p.scrollTop + p.clientHeight > p.scrollHeight - 60 && !el.more.hidden) runSearch(false);
  });
  el.keysBtn.addEventListener('click', () => setKeysOpen(el.keys.hidden));
  el.keys.addEventListener('submit', async (e) => {
    e.preventDefault();
    keys = { ...keys, klipy: el.keyKlipy.value.trim(), giphy: el.keyGiphy.value.trim() };
    await chrome.storage.local.set({ keys });
    renderChips();
    setKeysOpen(false);
    runSearch(true);
    flash('Keys saved');
  });

  chrome.storage.onChanged.addListener((changes, area) => {
    if (area !== 'local') return;
    if (changes.settings) {
      const next = { ...DEFAULTS, ...changes.settings.newValue };
      const mine = drag || Date.now() - lastViewWrite < 400;       // ignore echoes of our own framing writes
      settings = { ...next, view: mine ? view : { ...VIEW0, ...(next.view || {}) } };
      if (!mine) view = { ...settings.view };
      render();
    }
    if (changes.folderRev) loadDir();
  });

  // Keep the folder in sync while the popup is open (new / changed / deleted files appear within ~2 s).
  setInterval(() => { if (dir && !document.hidden) syncFolder(false); }, 2000);

  /* =============================== init =============================== */
  (async function init() {
    const { settings: s, media } = await chrome.storage.local.get(['settings', 'media']);
    settings = { ...DEFAULTS, ...(s || {}) };
    view = { ...VIEW0, ...(settings.view || {}) };
    settings.view = { ...view };
    if (settings.mediaId && media && media.id === settings.mediaId) {
      try { showPreview(await (await fetch(media.data)).blob(), media.mime); } catch (_) {}
    }
    render();
    loadDir();
  })();
})();
